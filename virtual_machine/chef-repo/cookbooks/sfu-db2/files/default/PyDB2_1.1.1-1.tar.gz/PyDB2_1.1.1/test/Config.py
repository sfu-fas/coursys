ConnDict = {
	'dsn':	'sample',
	'uid':	'db2inst1',
	'pwd':	'ibmdb2',
}
